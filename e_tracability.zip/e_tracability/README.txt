This plugin adds the eTracability button to the menu. 
When this is pressed, the plugin will check your loaded layers for the following columns:
Author, Date Created, Date Updated,
If it does not find them, it will add them.
It will also add in area and length for polygons and lines.